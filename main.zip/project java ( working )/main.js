let x;
let y;
x = 100;

console.log(x);